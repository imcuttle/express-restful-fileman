/**
 * @file decompress
 * @author Cuttle Cong
 * @date 2018/6/2
 * @description
 */
const _decompress = require('decompress')

function decompress(src, dest) {
  return _decompress(src, dest, {})
}
module.exports = decompress

decompress('')
