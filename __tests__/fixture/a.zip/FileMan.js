/**
 * @file Fileman
 * @author Cuttle Cong
 * @date 2018/6/2
 * @description
 */
const fs = require('fs')
const nps = require('path')
const pify = require('pify')
const assert = require('assert')
const mkdirp = require('mkdirp')
const rimraf = require('rimraf')

class FileMan {
  constructor(root) {
    root = nps.resolve(root)
    assert(
      fs.existsSync(root) && fs.statSync(root).isDirectory(),
      'root should be an directory.'
    )

    this.root = root
  }

  _p(p) {
    return nps.join(this.root, p)
  }

  mkdirp(path, opts) {
    return pify(mkdirp)(this._p(path), opts)
  }

  touch(path, data, options) {
    return this.mkdirp(nps.dirname(path)).then(() =>
      pify(fs.writeFile)(this._p(path), data, options)
    )
  }

  rm(path, options = {}) {
    return pify(rimraf)(this._p(path), options)
  }
}

module.exports = FileMan
